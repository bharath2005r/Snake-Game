
import javax.swing.*;

public class SnakeGame extends JFrame {

    
    public static void main(String[] args) {

            new LoginFrame();
        }
    }
